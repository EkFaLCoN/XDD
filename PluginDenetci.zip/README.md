# PluginDenetci

Sunucudaki eklentileri tarayıp açıkları, hataları ve çözümlerini raporlayan Paper eklentisi.

## Kurulum (telefondan)
1. GitHub'da yeni repo aç, bu zip'i (PluginDenetci.zip) repo köküne yükle (Add file > Upload files).
2. Repo'da Add file > Create new file, dosya adına `.github/workflows/build.yml` yaz, sohbetteki build.yml içeriğini yapıştır, commit et.
3. Actions zip'i açıp derler. Releases > latest altından `PluginDenetci.jar` dosyasını indir.
4. exaroton panelinden `plugins/` klasörüne yükle, sunucuyu yeniden başlat.

## Kullanım
- `/plugintara` : tüm eklentileri tarar
- `/plugintara <eklenti>` : tek eklentinin bulgularını çözümleriyle gösterir
- Rapor: `plugins/PluginDenetci/rapor-<tarih>.md`
- İzin: `plugindenetci.kullan` (varsayılan: op)
