package com.mrwqlf.plugindenetci;

import com.mrwqlf.plugindenetci.Finding.Severity;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/** Jar içindeki plugin.yml'i ve bytecode'u (class sabit havuzunu) tarar. */
public final class JarScanner {

    public record PluginInfo(String name, String version, String main, String api, File jar,
                             List<String> depend, Map<String, String> commands,
                             Map<String, String> permDefaults, boolean paper) {
    }

    private record Rule(String id, Severity sev, String title, String detail, String fix,
                        Predicate<Set<String>> test) {
    }

    private static final Set<String> SENSITIVE_TOKENS = Set.of(
            "admin", "op", "deop", "bypass", "reload", "give", "ban", "unban", "kick", "gamemode", "gm",
            "sudo", "console", "eval", "setrank", "rank", "manage", "setmoney", "addmoney", "givemoney",
            "eco", "economy", "fly", "god", "vanish", "clear", "wipe", "stop", "restart", "debug", "*");

    private static final String[] SENSITIVE_PREFIXES = {"set", "add", "give", "remove", "delete", "reset", "clear"};

    private static final List<Rule> RULES = List.of(
            new Rule("exec", Severity.YUKSEK,
                    "İşletim sistemi komutu çalıştırıyor (Runtime.exec)",
                    "Eklenti sunucu makinesinde komut çalıştırabiliyor. Kötü niyetli ya da hatalı kullanımda sunucuya tam erişime kadar gidebilir.",
                    "Kaynağı güvenilir değilse eklentiyi kaldır. Kendi eklentinse Runtime.exec yerine Bukkit/Paper API kullan; gerçekten gerekliyse komutu sabit bir beyaz listeden seç, kullanıcı girdisini asla komuta ekleme.",
                    s -> has(s, "java/lang/Runtime", "exec")),
            new Rule("procbuilder", Severity.YUKSEK,
                    "İşletim sistemi süreci başlatıyor (ProcessBuilder)",
                    "Eklenti sunucu makinesinde dış program çalıştırabiliyor.",
                    "Kaynağı güvenilir değilse eklentiyi kaldır. Kendi eklentinse gereksizse kodu sil; gerekliyse argümanları sabit tut ve kullanıcı girdisini karıştırma.",
                    s -> has(s, "java/lang/ProcessBuilder")),
            new Rule("classload", Severity.YUKSEK,
                    "Dışarıdan kod yükleyebiliyor (URLClassLoader / defineClass)",
                    "Çalışma sırasında indirilen ya da dışarıdan gelen kod sunucuda çalıştırılabilir. Kütüphane yükleyicileri de bunu kullanır, bu yüzden kaynağa bakmak gerekir.",
                    "Eklentiyi resmi kaynaktan (Modrinth/Hangar/Spigot) indirdiğinden emin ol. Kendi eklentinse bağımlılıkları jar'a göm (shade) ve çalışma anında kod indirme.",
                    s -> any(s, "java/net/URLClassLoader", "defineClass")),
            new Rule("script", Severity.YUKSEK,
                    "Betik motoru kullanıyor (ScriptEngine / GroovyShell)",
                    "Metin olarak verilen kod çalıştırılabiliyor; girdi kontrol edilmezse uzaktan kod çalıştırmaya yol açar.",
                    "Betik yüklenen dosyaların sadece yetkili kişilerce yazılabildiğinden emin ol, oyuncu girdisini asla betik olarak çalıştırma.",
                    s -> any(s, "javax/script/ScriptEngineManager", "groovy/lang/GroovyShell", "groovy/lang/GroovyClassLoader")),
            new Rule("webhook", Severity.YUKSEK,
                    "Koda gömülü webhook / bot adresi (veri sızdırma riski)",
                    "Discord webhook ya da Telegram bot adresi jar'ın içine gömülmüş. Kötü amaçlı eklentiler IP, token ve oyuncu verisini bu yolla dışarı gönderir.",
                    "Bu senin eklentin değilse kaldır. Kendi eklentinse adresi config'e al; paylaştığın jar'da token kalmadığından emin ol, sızdıysa webhook'u silip yenisini oluştur.",
                    s -> s.stream().anyMatch(x -> x.contains("discord.com/api/webhooks")
                            || x.contains("discordapp.com/api/webhooks") || x.contains("api.telegram.org/bot"))),
            new Rule("setop", Severity.YUKSEK,
                    "Oyunculara OP verebiliyor (setOp)",
                    "Kod içinde setOp çağrısı var. Hatalı bir koşul ya da arka kapı herkesi OP yapabilir.",
                    "Bu çağrının hangi koşulda çalıştığını incele. Kendi eklentinse kaldır, yetkileri OP yerine LuckPerms izinleriyle ver.",
                    s -> has(s, "setOp")),
            new Rule("unsafe", Severity.YUKSEK,
                    "Düşük seviyeli bellek erişimi (Unsafe)",
                    "sun.misc.Unsafe sunucuyu çökertebilir ve güvenlik katmanlarını aşar.",
                    "Kaynağı güvenilir değilse kaldır; kendi eklentinse Unsafe yerine standart API kullan.",
                    s -> any(s, "sun/misc/Unsafe", "jdk/internal/misc/Unsafe")),
            new Rule("dispatch", Severity.ORTA,
                    "Konsol yetkisiyle komut çalıştırıyor",
                    "dispatchCommand + konsol gönderici birlikte kullanılıyor. Oyuncudan gelen metin komuta karışırsa komut enjeksiyonu olur (ör. oyuncunun kendine OP vermesi).",
                    "Komuta eklenen her argümanı doğrula (sadece harf/rakam, uzunluk sınırı). Oyuncu adı gibi değerleri beyaz listeyle kontrol et, ham metni asla dispatchCommand'a verme.",
                    s -> has(s, "dispatchCommand", "getConsoleSender")),
            new Rule("sql", Severity.ORTA,
                    "SQL sorgusu hazırlıksız (Statement) çalışıyor",
                    "PreparedStatement yerine düz Statement var; oyuncu girdisi sorguya eklenirse SQL enjeksiyonu olur.",
                    "Sorguları PreparedStatement ve ? parametreleriyle yaz; metni '+' ile sorguya ekleme.",
                    s -> has(s, "java/sql/Statement") && !has(s, "java/sql/PreparedStatement")
                            && any(s, "executeQuery", "executeUpdate", "execute")),
            new Rule("sleep", Severity.ORTA,
                    "Thread.sleep kullanıyor (olası lag)",
                    "Ana thread'de çağrılırsa sunucu o süre boyunca donar (TPS düşer).",
                    "Bekleme için BukkitScheduler.runTaskLater / runTaskTimer kullan; ağır işleri runTaskAsynchronously ile ayrı thread'e al.",
                    s -> has(s, "java/lang/Thread", "sleep")),
            new Rule("exit", Severity.ORTA,
                    "Sunucuyu kapatabilecek çağrı (System.exit)",
                    "System.exit sunucuyu veri kaydetmeden aniden kapatır, dünyalar bozulabilir.",
                    "Kapatma gerekiyorsa Bukkit.shutdown() kullan. Kaynağı belirsizse eklentiyi kaldır.",
                    s -> has(s, "java/lang/System", "exit")),
            new Rule("deser", Severity.ORTA,
                    "Güvenilmeyen veriyi nesneye çeviriyor (ObjectInputStream)",
                    "Java deserialization açıkları uzaktan kod çalıştırmaya yol açabilir.",
                    "Veriyi JSON/YAML ile sakla; ObjectInputStream gerekliyse sadece kendi yazdığın dosyaları oku.",
                    s -> has(s, "java/io/ObjectInputStream", "readObject")),
            new Rule("nms", Severity.ORTA,
                    "Sürüme bağlı iç kod (NMS/CraftBukkit) kullanıyor",
                    "Minecraft güncellenince bu eklenti çökebilir veya çalışmayabilir.",
                    "26.2 ile uyumlu sürümünü indir/güncelle. Kendi eklentinse Paper API ya da paperweight-userdev kullan.",
                    s -> startsAny(s, "net/minecraft/server/v1_", "org/bukkit/craftbukkit/v1_")),
            new Rule("network", Severity.ORTA,
                    "Ağ bağlantısı kuruyor",
                    "Eklenti internete/sunucuya bağlanıyor. Kötü niyetli olmak zorunda değil (güncelleme kontrolü, Discord botu vs.) ama nereye bağlandığını bilmen gerekir.",
                    "Hangi adreslere bağlandığını incele; gerekmiyorsa güvenlik duvarıyla ya da eklentiyi kaldırarak engelle.",
                    s -> any(s, "java/net/Socket", "java/net/ServerSocket", "java/net/http/HttpClient",
                            "java/net/HttpURLConnection")),
            new Rule("filedel", Severity.DUSUK,
                    "Dosya siliyor",
                    "Eklenti dosya/klasör silebiliyor; yol hatası dünya veya config dosyalarını silebilir.",
                    "Silinen yolun sabit ve plugin klasörü içinde olduğunu kontrol et; silmeden önce yedek al.",
                    s -> (has(s, "java/nio/file/Files") && any(s, "delete", "deleteIfExists"))
                            || has(s, "java/io/File", "delete")),
            new Rule("reflect", Severity.DUSUK,
                    "Reflection ile iç erişim (setAccessible)",
                    "Sürüm güncellemelerinde sessizce bozulur, bazı güvenlik kontrollerini atlar.",
                    "Eklenti güncel mi kontrol et; kendi eklentinse Paper API'deki karşılığını kullan.",
                    s -> has(s, "setAccessible", "java/lang/reflect/Method")),
            new Rule("stacktrace", Severity.DUSUK,
                    "printStackTrace kullanıyor",
                    "Hatalar log'a düzgün seviyeyle yazılmıyor, bu yüzden sorunlar fark edilmeden kalır.",
                    "getLogger().log(Level.SEVERE, \"mesaj\", exception) kullan.",
                    s -> has(s, "printStackTrace"))
    );

    private JarScanner() {
    }

    // ------------------------------------------------------------------ plugin.yml

    /** plugin.yml (yoksa paper-plugin.yml) okur; bulunamazsa/bozuksa null döner. */
    public static PluginInfo readInfo(File jar) {
        try (JarFile jf = new JarFile(jar)) {
            boolean paper = false;
            JarEntry e = jf.getJarEntry("plugin.yml");
            if (e == null) {
                e = jf.getJarEntry("paper-plugin.yml");
                paper = true;
            }
            if (e == null) {
                return null;
            }
            YamlConfiguration y = new YamlConfiguration();
            try (InputStream in = jf.getInputStream(e)) {
                y.loadFromString(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            }
            String name = y.getString("name", jar.getName());
            String version = y.getString("version", "?");
            String main = y.getString("main", "");
            String api = y.getString("api-version");
            List<String> depend = new ArrayList<>(list(y, "depend"));

            Map<String, String> commands = new LinkedHashMap<>();
            Map<String, String> permDefaults = new LinkedHashMap<>();
            if (!paper) {
                ConfigurationSection cs = y.getConfigurationSection("commands");
                if (cs != null) {
                    for (String k : cs.getKeys(false)) {
                        commands.put(k, cs.getString(k + ".permission"));
                    }
                }
                ConfigurationSection ps = y.getConfigurationSection("permissions");
                if (ps != null) {
                    for (String k : ps.getKeys(true)) {
                        if (k.endsWith(".default")) {
                            permDefaults.put(k.substring(0, k.length() - ".default".length()),
                                    String.valueOf(ps.get(k)));
                        }
                    }
                }
            }
            return new PluginInfo(name, version, main, api, jar, depend, commands, permDefaults, paper);
        } catch (Exception ex) {
            return null;
        }
    }

    private static List<String> list(YamlConfiguration y, String key) {
        if (y.isList(key)) {
            return y.getStringList(key);
        }
        if (y.isString(key)) {
            return List.of(y.getString(key, ""));
        }
        return List.of();
    }

    // ------------------------------------------------------------------ plugin.yml bulguları

    public static List<Finding> manifestFindings(PluginInfo info, Set<String> allNamesLower, String serverMc) {
        List<Finding> out = new ArrayList<>();
        String p = info.name();

        if (info.api() == null || info.api().isBlank()) {
            out.add(new Finding(p, Severity.ORTA, "api-version yok (eski/legacy eklenti gibi yükleniyor)",
                    "plugin.yml içinde api-version tanımlı değil. Sunucu uyumluluk katmanı açar; performans düşer, Material/eşya hataları çıkabilir.",
                    "plugin.yml'e api-version: '" + majorMinor(serverMc) + "' ekle ve yeniden derle. Kendi eklentin değilse güncel sürümünü indir."));
        } else {
            String mm = majorMinor(serverMc);
            if (info.api().startsWith("1.") && !serverMc.startsWith("1.")) {
                out.add(new Finding(p, Severity.ORTA, "Eski sürüm için derlenmiş (api-version " + info.api() + ")",
                        "Eklenti 1.x sürümleri için hazırlanmış, sunucu ise " + serverMc + ". Hata verebilir veya özellikleri eksik çalışabilir.",
                        "Eklentinin " + mm + " ile uyumlu sürümünü indir ya da kendi eklentinse api-version'u güncelleyip paper-api " + mm + " ile derle."));
            } else if (!info.api().equals(mm)) {
                out.add(new Finding(p, Severity.DUSUK, "api-version sunucudan farklı (" + info.api() + " ≠ " + mm + ")",
                        "Eklenti başka bir API sürümü için derlenmiş; çoğu zaman çalışır ama uyumsuzluk çıkabilir.",
                        "Güncel sürümünü kontrol et; kendi eklentinse api-version'u '" + mm + "' yap."));
            }
        }

        for (String d : info.depend()) {
            if (!allNamesLower.contains(d.toLowerCase(Locale.ROOT))) {
                out.add(new Finding(p, Severity.YUKSEK, "Zorunlu bağımlılık eksik: " + d,
                        "plugin.yml'de depend olarak yazılmış ama plugins klasöründe bu eklenti yok; " + p + " yüklenemez.",
                        d + " eklentisini plugins klasörüne ekle (uyumlu sürüm) ya da gerekmiyorsa depend satırını softdepend yap."));
            }
        }

        List<String> sensitiveNoPerm = new ArrayList<>();
        List<String> otherNoPerm = new ArrayList<>();
        for (Map.Entry<String, String> c : info.commands().entrySet()) {
            if (c.getValue() == null || c.getValue().isBlank()) {
                if (isSensitiveName(c.getKey())) {
                    sensitiveNoPerm.add("/" + c.getKey());
                } else {
                    otherNoPerm.add("/" + c.getKey());
                }
            }
        }
        if (!sensitiveNoPerm.isEmpty()) {
            out.add(new Finding(p, Severity.YUKSEK, "Yönetici işlevli komutlar permission'sız: " + String.join(", ", sensitiveNoPerm),
                    "plugin.yml'de bu komutlara permission tanımlı değil. Kod içinde ayrıca yetki kontrolü yoksa her oyuncu çalıştırabilir.",
                    "Komuta plugin.yml'de permission ekle (ör. permission: " + p.toLowerCase(Locale.ROOT) + ".admin) ve onCommand içinde sender.hasPermission ile kontrol et. Hemen test için LuckPerms'te normal oyuncuyla dene."));
        }
        if (!otherNoPerm.isEmpty()) {
            out.add(new Finding(p, Severity.DUSUK, otherNoPerm.size() + " komut permission'sız",
                    "Komutlar: " + String.join(", ", otherNoPerm.subList(0, Math.min(8, otherNoPerm.size())))
                            + (otherNoPerm.size() > 8 ? " ..." : "")
                            + ". Oyuncu komutları için normal olabilir.",
                    "Yönetici etkisi olan komut varsa permission ekle; herkese açık komutlar için sorun yok."));
        }

        for (Map.Entry<String, String> e : info.permDefaults().entrySet()) {
            if ("true".equalsIgnoreCase(e.getValue()) && isSensitiveName(e.getKey())) {
                out.add(new Finding(p, Severity.YUKSEK, "Yönetici izni herkese açık: " + e.getKey(),
                        "Bu izin default: true olduğu için tüm oyuncularda varsayılan olarak açık.",
                        "plugin.yml'de bu iznin default değerini op yap (default: op) ve yetkiyi LuckPerms ile ver."));
            }
        }
        return out;
    }

    private static boolean isSensitiveName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.contains("*")) {
            return true;
        }
        for (String t : n.split("[.\\-_ ]")) {
            if (SENSITIVE_TOKENS.contains(t)) {
                return true;
            }
        }
        String last = n.contains(".") ? n.substring(n.lastIndexOf('.') + 1) : n;
        for (String pre : SENSITIVE_PREFIXES) {
            if (last.startsWith(pre) && last.length() > pre.length()) {
                return true;
            }
        }
        return false;
    }

    static String majorMinor(String ver) {
        String[] seg = ver.split("[.\\-]");
        if (seg.length >= 2) {
            return seg[0] + "." + seg[1];
        }
        return ver;
    }

    // ------------------------------------------------------------------ bytecode

    public static List<Finding> scanBytecode(PluginInfo info) {
        List<Finding> out = new ArrayList<>();
        String scope = pkgRoot(info.main(), 2).replace('.', '/');
        if (!scope.isEmpty()) {
            scope += "/";
        }
        Map<String, List<String>> hits = new LinkedHashMap<>();
        Set<String> httpHosts = new LinkedHashSet<>();
        int classCount = 0;
        int shortNames = 0;

        try (JarFile jf = new JarFile(info.jar())) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                String n = e.getName();
                if (!n.endsWith(".class") || n.startsWith("META-INF/") || e.getSize() > 3_000_000) {
                    continue;
                }
                if (!inScope(n, scope)) {
                    continue;
                }
                Set<String> strs;
                try (InputStream in = jf.getInputStream(e)) {
                    strs = readStrings(in);
                } catch (IOException ex) {
                    continue;
                }
                classCount++;
                String cls = n.substring(0, n.length() - 6);
                String simple = cls.substring(cls.lastIndexOf('/') + 1);
                if (simple.length() <= 2) {
                    shortNames++;
                }
                String dotted = cls.replace('/', '.');
                for (Rule r : RULES) {
                    if (r.test().test(strs)) {
                        hits.computeIfAbsent(r.id(), k -> new ArrayList<>()).add(dotted);
                    }
                }
                for (String x : strs) {
                    if (x.startsWith("http://") && httpHosts.size() < 6) {
                        String host = x.substring(7).split("[/:?#\\s]")[0];
                        if (!host.isEmpty() && host.length() < 60 && !ignoredHost(host)) {
                            httpHosts.add(host);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            out.add(new Finding(info.name(), Severity.BILGI, "Jar okunamadı",
                    "Bytecode taraması yapılamadı: " + ex.getClass().getSimpleName(),
                    "Jar dosyasının bozuk olmadığından emin ol, yeniden indir."));
            return out;
        }

        for (Rule r : RULES) {
            List<String> cl = hits.get(r.id());
            if (cl == null) {
                continue;
            }
            out.add(new Finding(info.name(), r.sev(), r.title(),
                    r.detail() + " Bulunduğu sınıflar: " + sample(cl) + ".", r.fix()));
        }
        if (!httpHosts.isEmpty()) {
            out.add(new Finding(info.name(), Severity.ORTA, "Şifresiz HTTP adresi kullanıyor",
                    "Kodda http:// adresleri var: " + String.join(", ", httpHosts) + ". Trafik şifresiz gider, araya girilebilir.",
                    "https:// kullan. Adres senin değilse eklentinin kaynağını kontrol et."));
        }
        if (classCount >= 10 && shortNames * 100 / classCount >= 60) {
            out.add(new Finding(info.name(), Severity.ORTA, "Kod karartılmış (obfuscated)",
                    "Sınıfların büyük kısmı a, b, c gibi tek-iki harfli isimlere sahip. Ne yaptığı denetlenemez.",
                    "Eklentiyi sadece resmi kaynaktan indir; kaynağı doğrulanamıyorsa kullanma."));
        }
        return out;
    }

    private static String sample(List<String> cl) {
        List<String> shown = cl.subList(0, Math.min(3, cl.size()));
        return String.join(", ", shown) + (cl.size() > 3 ? " (+" + (cl.size() - 3) + ")" : "");
    }

    private static boolean ignoredHost(String h) {
        h = h.toLowerCase(Locale.ROOT);
        return h.equals("localhost") || h.startsWith("127.") || h.contains("w3.org") || h.contains("schemas")
                || h.contains("java.sun.com") || h.contains("xml.org") || h.contains("apache.org")
                || h.contains("maven.apache") || h.contains("www.springframework") || h.contains("xmlpull");
    }

    private static boolean inScope(String entry, String scope) {
        String lower = entry.toLowerCase(Locale.ROOT);
        if (lower.contains("/libs/") || lower.contains("/lib/") || lower.contains("/shaded/")
                || lower.contains("/relocated/") || lower.contains("/thirdparty/")
                || lower.contains("/third_party/") || lower.contains("/dependencies/")
                || lower.contains("/repack/")) {
            return false;
        }
        return scope.isEmpty() || entry.startsWith(scope);
    }

    /** main sınıfının paketinden en fazla n segment (ör. com.foo.bar.Main, 2 → com.foo). */
    public static String pkgRoot(String main, int n) {
        if (main == null) {
            return "";
        }
        String[] seg = main.split("\\.");
        int pk = seg.length - 1;
        if (pk <= 0) {
            return "";
        }
        int take = Math.min(n, pk);
        return String.join(".", java.util.Arrays.copyOfRange(seg, 0, take));
    }

    // ------------------------------------------------------------------ class parse

    private static Set<String> readStrings(InputStream in) throws IOException {
        DataInputStream d = new DataInputStream(new BufferedInputStream(in));
        Set<String> out = new HashSet<>();
        if (d.readInt() != 0xCAFEBABE) {
            return out;
        }
        d.readUnsignedShort();
        d.readUnsignedShort();
        int n = d.readUnsignedShort();
        for (int i = 1; i < n; i++) {
            int tag = d.readUnsignedByte();
            switch (tag) {
                case 1 -> out.add(d.readUTF());
                case 3, 4, 9, 10, 11, 12, 17, 18 -> d.skipNBytes(4);
                case 5, 6 -> {
                    d.skipNBytes(8);
                    i++;
                }
                case 7, 8, 16, 19, 20 -> d.skipNBytes(2);
                case 15 -> d.skipNBytes(3);
                default -> {
                    return out;
                }
            }
        }
        return out;
    }

    private static boolean has(Set<String> s, String... keys) {
        for (String k : keys) {
            if (!s.contains(k)) {
                return false;
            }
        }
        return true;
    }

    private static boolean any(Set<String> s, String... keys) {
        for (String k : keys) {
            if (s.contains(k)) {
                return true;
            }
        }
        return false;
    }

    private static boolean startsAny(Set<String> s, String... prefixes) {
        for (String x : s) {
            for (String p : prefixes) {
                if (x.startsWith(p)) {
                    return true;
                }
            }
        }
        return false;
    }
}
