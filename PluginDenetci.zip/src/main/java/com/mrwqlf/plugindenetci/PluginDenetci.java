package com.mrwqlf.plugindenetci;

import com.mrwqlf.plugindenetci.Finding.Severity;
import com.mrwqlf.plugindenetci.JarScanner.PluginInfo;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

public final class PluginDenetci extends JavaPlugin implements TabExecutor {

    private final AtomicBoolean running = new AtomicBoolean(false);

    @Override
    public void onEnable() {
        PluginCommand cmd = getCommand("plugintara");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("PluginDenetci hazır. Kullanım: /plugintara [eklenti-adı]");
    }

    // ------------------------------------------------------------------ komut

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!running.compareAndSet(false, true)) {
            send(sender, NamedTextColor.RED, "Tarama zaten sürüyor, bitmesini bekle.");
            return true;
        }
        String filter = null;
        if (args.length > 0 && !args[0].equalsIgnoreCase("calistir") && !args[0].equalsIgnoreCase("hepsi")) {
            filter = args[0];
        }
        final String fFilter = filter;

        // Bukkit durumu ana thread'de alınır
        final String serverMc = Bukkit.getMinecraftVersion();
        final Map<String, Boolean> enabled = new HashMap<>();
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            enabled.put(p.getName().toLowerCase(Locale.ROOT), p.isEnabled());
        }
        final String ownName = getName();
        final File pluginsDir = getDataFolder().getParentFile();
        final File root = pluginsDir.getParentFile();

        send(sender, NamedTextColor.YELLOW, "Eklentiler taranıyor, bu birkaç saniye sürebilir...");

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try {
                List<Finding> all = audit(pluginsDir, root, ownName, serverMc, enabled);
                all.sort(Comparator.comparingInt((Finding f) -> f.severity().ordinal())
                        .thenComparing(Finding::plugin).thenComparing(Finding::title));
                int pluginCount = countJars(pluginsDir);
                File report = writeReport(all, serverMc, pluginCount);
                Bukkit.getScheduler().runTask(this, () -> present(sender, all, fFilter, report, pluginCount));
            } catch (Throwable t) {
                getLogger().log(Level.SEVERE, "Tarama sırasında hata", t);
                Bukkit.getScheduler().runTask(this, () ->
                        send(sender, NamedTextColor.RED, "Tarama hata verdi: " + t.getClass().getSimpleName()
                                + " (ayrıntı konsol log'unda)."));
            } finally {
                running.set(false);
            }
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) {
            return List.of();
        }
        List<String> out = new ArrayList<>();
        out.add("calistir");
        for (Plugin p : Bukkit.getPluginManager().getPlugins()) {
            out.add(p.getName());
        }
        String pre = args[0].toLowerCase(Locale.ROOT);
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(pre));
        return out;
    }

    // ------------------------------------------------------------------ tarama

    private static int countJars(File pluginsDir) {
        File[] jars = pluginsDir.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".jar"));
        return jars == null ? 0 : jars.length;
    }

    private List<Finding> audit(File pluginsDir, File root, String ownName, String serverMc,
                                Map<String, Boolean> enabled) {
        List<Finding> all = new ArrayList<>();
        File[] jars = pluginsDir.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".jar"));
        if (jars == null) {
            return all;
        }
        List<PluginInfo> infos = new ArrayList<>();
        Set<String> namesLower = new HashSet<>();
        Map<String, List<String>> nameToJars = new LinkedHashMap<>();

        for (File jar : jars) {
            PluginInfo info = JarScanner.readInfo(jar);
            if (info == null) {
                all.add(new Finding(jar.getName(), Severity.DUSUK, "plugin.yml okunamadı",
                        "Jar'da plugin.yml/paper-plugin.yml yok ya da bozuk. Kütüphane/eklenti uzantısı olabilir; değilse eklenti yüklenmez.",
                        "Dosyayı resmi kaynaktan yeniden indir. Eklenti değil de kütüphaneyse plugins klasöründen kaldırabilirsin."));
                continue;
            }
            infos.add(info);
            namesLower.add(info.name().toLowerCase(Locale.ROOT));
            nameToJars.computeIfAbsent(info.name().toLowerCase(Locale.ROOT), k -> new ArrayList<>())
                    .add(jar.getName());
        }

        for (Map.Entry<String, List<String>> e : nameToJars.entrySet()) {
            if (e.getValue().size() > 1) {
                all.add(new Finding(e.getKey(), Severity.ORTA, "Aynı eklentiden birden fazla jar var",
                        "Dosyalar: " + String.join(", ", e.getValue()) + ". Hangisinin yükleneceği belli olmaz, çakışma çıkar.",
                        "Eski sürümü plugins klasöründen sil, sadece güncel jar kalsın."));
            }
        }

        for (PluginInfo info : infos) {
            boolean own = info.name().equalsIgnoreCase(ownName);
            Boolean en = enabled.get(info.name().toLowerCase(Locale.ROOT));
            if (en == null) {
                all.add(new Finding(info.name(), Severity.YUKSEK, "Sunucuda yüklü görünmüyor",
                        "Jar plugins klasöründe ama sunucu eklenti listesinde yok; yüklenememiş olabilir (ya da sunucu yeniden başlatılmadı).",
                        "Sunucuyu yeniden başlat; hâlâ yoksa başlangıç log'unda bu eklentinin hatasına bak."));
            } else if (!en) {
                all.add(new Finding(info.name(), Severity.KRITIK, "Eklenti kapalı (etkinleştirilemedi)",
                        "Eklenti yüklenmiş ama devre dışı kalmış; çoğunlukla başlangıçta hata vermiştir.",
                        "latest.log içinde '" + info.name() + "' geçen ERROR satırına bak; eksik bağımlılık ya da sürüm uyumsuzluğu en sık nedenlerdir."));
            }
            all.addAll(JarScanner.manifestFindings(info, namesLower, serverMc));
            if (!own) {
                all.addAll(JarScanner.scanBytecode(info));
            }
        }

        try {
            ExtraChecks.configSecrets(pluginsDir, ownName, all);
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Config taraması başarısız", e);
        }
        try {
            ExtraChecks.serverProperties(root, all);
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "server.properties taraması başarısız", e);
        }
        try {
            ExtraChecks.log(new File(root, "logs/latest.log"), infos, all);
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Log taraması başarısız", e);
        }
        return all;
    }

    // ------------------------------------------------------------------ rapor dosyası

    private File writeReport(List<Finding> all, String serverMc, int pluginCount) throws Exception {
        File dir = getDataFolder();
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Rapor klasörü oluşturulamadı");
        }
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm"));
        File out = new File(dir, "rapor-" + stamp + ".md");

        StringBuilder sb = new StringBuilder();
        sb.append("# Plugin Denetim Raporu\n\n");
        sb.append("- Tarih: ").append(stamp.replace('_', ' ')).append('\n');
        sb.append("- Sunucu sürümü: ").append(serverMc).append('\n');
        sb.append("- Taranan jar sayısı: ").append(pluginCount).append('\n');
        sb.append("- Toplam bulgu: ").append(all.size()).append("\n\n");

        Map<String, EnumMap<Severity, Integer>> counts = countsByPlugin(all);
        sb.append("## Özet\n\n| Eklenti | Kritik | Yüksek | Orta | Düşük |\n|---|---|---|---|---|\n");
        for (Map.Entry<String, EnumMap<Severity, Integer>> e : sortedPlugins(counts)) {
            EnumMap<Severity, Integer> c = e.getValue();
            sb.append("| ").append(e.getKey()).append(" | ")
                    .append(c.getOrDefault(Severity.KRITIK, 0)).append(" | ")
                    .append(c.getOrDefault(Severity.YUKSEK, 0)).append(" | ")
                    .append(c.getOrDefault(Severity.ORTA, 0)).append(" | ")
                    .append(c.getOrDefault(Severity.DUSUK, 0)).append(" |\n");
        }
        sb.append('\n');

        String current = null;
        for (Map.Entry<String, EnumMap<Severity, Integer>> pe : sortedPlugins(counts)) {
            String plugin = pe.getKey();
            if (!plugin.equals(current)) {
                sb.append("## ").append(plugin).append("\n\n");
                current = plugin;
            }
            for (Finding f : all) {
                if (!f.plugin().equals(plugin)) {
                    continue;
                }
                sb.append("### [").append(f.severity().label).append("] ").append(f.title()).append("\n\n");
                sb.append("- **Ne var:** ").append(f.detail()).append('\n');
                sb.append("- **Çözüm:** ").append(f.fix()).append("\n\n");
            }
        }
        sb.append("---\n");
        sb.append("Bu rapor otomatik statik analizdir; olası yanlış pozitifler içerir. ");
        sb.append("Bytecode kuralları, jar içindeki kütüphane (shade) kodunu elemeye çalışır ama her zaman başaramaz. ");
        sb.append("Config'teki şifre/token değerleri rapora yazılmaz.\n");

        Files.writeString(out.toPath(), sb.toString(), StandardCharsets.UTF_8);
        return out;
    }

    private static Map<String, EnumMap<Severity, Integer>> countsByPlugin(List<Finding> all) {
        Map<String, EnumMap<Severity, Integer>> m = new LinkedHashMap<>();
        for (Finding f : all) {
            m.computeIfAbsent(f.plugin(), k -> new EnumMap<>(Severity.class)).merge(f.severity(), 1, Integer::sum);
        }
        return m;
    }

    private static List<Map.Entry<String, EnumMap<Severity, Integer>>> sortedPlugins(
            Map<String, EnumMap<Severity, Integer>> counts) {
        List<Map.Entry<String, EnumMap<Severity, Integer>>> list = new ArrayList<>(counts.entrySet());
        list.sort((a, b) -> {
            int[] x = weight(a.getValue());
            int[] y = weight(b.getValue());
            for (int i = 0; i < x.length; i++) {
                if (x[i] != y[i]) {
                    return Integer.compare(y[i], x[i]);
                }
            }
            return a.getKey().compareToIgnoreCase(b.getKey());
        });
        return list;
    }

    private static int[] weight(EnumMap<Severity, Integer> c) {
        return new int[]{c.getOrDefault(Severity.KRITIK, 0), c.getOrDefault(Severity.YUKSEK, 0),
                c.getOrDefault(Severity.ORTA, 0), c.getOrDefault(Severity.DUSUK, 0)};
    }

    // ------------------------------------------------------------------ sohbete çıktı

    private void present(CommandSender sender, List<Finding> all, String filter, File report, int pluginCount) {
        if (filter != null) {
            List<Finding> mine = new ArrayList<>();
            for (Finding f : all) {
                if (f.plugin().equalsIgnoreCase(filter)) {
                    mine.add(f);
                }
            }
            if (mine.isEmpty()) {
                send(sender, NamedTextColor.GREEN, filter + " için bulgu yok (ya da isim yanlış).");
            } else {
                send(sender, NamedTextColor.GOLD, "== " + mine.get(0).plugin() + ": " + mine.size() + " bulgu ==");
                int shown = 0;
                for (Finding f : mine) {
                    if (shown++ >= 10) {
                        send(sender, NamedTextColor.GRAY, "... kalanı raporda.");
                        break;
                    }
                    send(sender, color(f.severity()), "[" + f.severity().label + "] " + f.title());
                    send(sender, NamedTextColor.GRAY, "  Çözüm: " + shorten(f.fix(), 220));
                }
            }
            send(sender, NamedTextColor.AQUA, "Tam rapor: plugins/" + getName() + "/" + report.getName());
            return;
        }

        Map<Severity, Integer> total = new EnumMap<>(Severity.class);
        for (Finding f : all) {
            total.merge(f.severity(), 1, Integer::sum);
        }
        send(sender, NamedTextColor.GOLD, "== Plugin taraması bitti: " + pluginCount + " jar, " + all.size() + " bulgu ==");
        send(sender, NamedTextColor.WHITE, "Kritik " + total.getOrDefault(Severity.KRITIK, 0)
                + " | Yüksek " + total.getOrDefault(Severity.YUKSEK, 0)
                + " | Orta " + total.getOrDefault(Severity.ORTA, 0)
                + " | Düşük " + total.getOrDefault(Severity.DUSUK, 0));

        int lines = 0;
        for (Map.Entry<String, EnumMap<Severity, Integer>> e : sortedPlugins(countsByPlugin(all))) {
            if (lines++ >= 12) {
                send(sender, NamedTextColor.GRAY, "... diğer eklentiler raporda.");
                break;
            }
            int[] w = weight(e.getValue());
            send(sender, NamedTextColor.GRAY, e.getKey() + ": " + w[0] + " kritik, " + w[1] + " yüksek, "
                    + w[2] + " orta, " + w[3] + " düşük");
        }

        int top = 0;
        for (Finding f : all) {
            if (f.severity() != Severity.KRITIK && f.severity() != Severity.YUKSEK) {
                continue;
            }
            if (top++ >= 6) {
                break;
            }
            send(sender, color(f.severity()), "[" + f.severity().label + "] " + f.plugin() + ": " + f.title());
            send(sender, NamedTextColor.GRAY, "  Çözüm: " + shorten(f.fix(), 160));
        }
        send(sender, NamedTextColor.AQUA, "Tam rapor: plugins/" + getName() + "/" + report.getName()
                + "  |  Tek eklenti: /plugintara <ad>");
        getLogger().info("Tarama bitti: " + all.size() + " bulgu. Rapor: " + report.getName());
    }

    private static TextColor color(Severity s) {
        return switch (s) {
            case KRITIK -> NamedTextColor.DARK_RED;
            case YUKSEK -> NamedTextColor.RED;
            case ORTA -> NamedTextColor.GOLD;
            case DUSUK -> NamedTextColor.YELLOW;
            case BILGI -> NamedTextColor.GRAY;
        };
    }

    private static String shorten(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n) + "...";
    }

    private static void send(CommandSender sender, TextColor color, String text) {
        sender.sendMessage(Component.text(text, color));
    }
}
