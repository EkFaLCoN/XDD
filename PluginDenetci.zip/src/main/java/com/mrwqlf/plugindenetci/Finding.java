package com.mrwqlf.plugindenetci;

/** Tek bir bulgu: hangi eklenti, ne kadar ciddi, ne var, nasıl çözülür. */
public record Finding(String plugin, Severity severity, String title, String detail, String fix) {

    public enum Severity {
        KRITIK("KRİTİK"),
        YUKSEK("YÜKSEK"),
        ORTA("ORTA"),
        DUSUK("DÜŞÜK"),
        BILGI("BİLGİ");

        public final String label;

        Severity(String label) {
            this.label = label;
        }
    }
}
