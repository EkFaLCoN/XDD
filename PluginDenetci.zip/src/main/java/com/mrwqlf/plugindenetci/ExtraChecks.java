package com.mrwqlf.plugindenetci;

import com.mrwqlf.plugindenetci.Finding.Severity;
import com.mrwqlf.plugindenetci.JarScanner.PluginInfo;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Config dosyaları, server.properties ve latest.log kontrolleri. */
public final class ExtraChecks {

    private ExtraChecks() {
    }

    // ------------------------------------------------------------------ config içinde düz metin sır

    private static final Pattern SECRET = Pattern.compile(
            "^\\s*([\\w.-]*(?:password|passwd|token|secret|api[-_]?key|webhook[-_]?url|private[-_]?key)[\\w.-]*)\\s*:\\s*(.+?)\\s*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern KEY_DENY = Pattern.compile(
            "(?i)message|msg|text|lore|name|format|prefix|title|usage|perm|enable|required|command|cmd|timeout|length|min|max|count|cooldown|limit|display|desc|bypass|hint");

    public static void configSecrets(File pluginsDir, String ownName, List<Finding> out) {
        File[] dirs = pluginsDir.listFiles(File::isDirectory);
        if (dirs == null) {
            return;
        }
        for (File dir : dirs) {
            if (dir.getName().equalsIgnoreCase(ownName)) {
                continue;
            }
            File[] ymls = dir.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".yml"));
            if (ymls == null) {
                continue;
            }
            for (File f : ymls) {
                if (f.length() > 1_000_000) {
                    continue;
                }
                List<String> found = new ArrayList<>();
                try {
                    List<String> lines = Files.readAllLines(f.toPath(), StandardCharsets.ISO_8859_1);
                    for (int i = 0; i < lines.size(); i++) {
                        Matcher m = SECRET.matcher(lines.get(i));
                        if (!m.matches()) {
                            continue;
                        }
                        String key = m.group(1);
                        if (KEY_DENY.matcher(key).find()) {
                            continue;
                        }
                        if (!looksLikeRealSecret(m.group(2))) {
                            continue;
                        }
                        found.add(key + " (satır " + (i + 1) + ")");
                    }
                } catch (Exception ignored) {
                    continue;
                }
                if (!found.isEmpty()) {
                    out.add(new Finding(dir.getName(), Severity.YUKSEK,
                            "Config'te düz metin şifre/token olabilir: " + f.getName(),
                            "Şu anahtarlarda dolu değer var: " + String.join(", ", found.subList(0, Math.min(4, found.size())))
                                    + ". (Değerler rapora yazılmaz.)",
                            "Bu dosyayı kimseyle paylaşma (rapor, zip, GitHub). Token/şifre başkasının eline geçtiyse hemen yenile. Eklenti destekliyorsa ortam değişkeni ya da ayrı gizli dosya kullan."));
                }
            }
        }
    }

    private static boolean looksLikeRealSecret(String raw) {
        String v = raw;
        int hash = v.indexOf(" #");
        if (hash >= 0) {
            v = v.substring(0, hash);
        }
        v = v.trim();
        if (v.length() >= 2 && (v.startsWith("\"") && v.endsWith("\"") || v.startsWith("'") && v.endsWith("'"))) {
            v = v.substring(1, v.length() - 1);
        }
        v = v.trim();
        if (v.length() < 4) {
            return false;
        }
        String l = v.toLowerCase(Locale.ROOT);
        if (l.equals("null") || l.equals("none") || l.equals("true") || l.equals("false") || l.equals("[]")
                || l.equals("{}") || l.equals("~")) {
            return false;
        }
        return !(l.startsWith("your") || l.startsWith("change") || l.startsWith("<") || l.startsWith("${")
                || l.startsWith("%") || l.startsWith("example") || l.startsWith("|") || l.startsWith(">")
                || l.startsWith("&") || l.startsWith("*") || l.startsWith("!"));
    }

    // ------------------------------------------------------------------ server.properties

    public static void serverProperties(File root, List<Finding> out) {
        File f = new File(root, "server.properties");
        if (!f.isFile()) {
            return;
        }
        Properties p = new Properties();
        try (var in = Files.newInputStream(f.toPath())) {
            p.load(in);
        } catch (Exception e) {
            return;
        }
        if ("false".equalsIgnoreCase(p.getProperty("online-mode", "true").trim())) {
            out.add(new Finding("Sunucu", Severity.YUKSEK, "online-mode kapalı",
                    "Sunucu oyuncuların Mojang hesabını doğrulamıyor; biri senin ya da bir adminin kullanıcı adıyla girip OP yetkisini kullanabilir. (Velocity/BungeeCord arkasındaysan normaldir.)",
                    "Proxy kullanmıyorsan exaroton panelinde sunucu ayarlarından Online Mode'u aç."));
        }
        if ("true".equalsIgnoreCase(p.getProperty("enable-rcon", "false").trim())) {
            String pw = p.getProperty("rcon.password", "").trim();
            if (pw.isEmpty()) {
                out.add(new Finding("Sunucu", Severity.KRITIK, "RCON açık ve şifresi boş",
                        "Uzaktan konsol erişimi şifresiz; internetten herkes sunucuya komut gönderebilir.",
                        "enable-rcon'u kapat ya da güçlü bir rcon.password belirle."));
            } else {
                out.add(new Finding("Sunucu", Severity.ORTA, "RCON açık",
                        "Uzaktan konsol erişimi açık; şifre zayıfsa brute-force ile ele geçirilebilir.",
                        "Kullanmıyorsan enable-rcon=false yap; kullanıyorsan uzun/rastgele şifre koy ve portu dışarı açma."));
            }
        }
    }

    // ------------------------------------------------------------------ latest.log

    private static final Pattern LEVEL_TAG = Pattern.compile("^\\[[^\\]]*\\b(ERROR|WARN)\\]: \\[([^\\]]+)\\] (.*)$");
    private static final Pattern EVENT = Pattern.compile("Could not pass event (\\S+) to ([^\\s]+)");
    private static final Pattern ENABLE = Pattern.compile("Error occurred while enabling ([^\\s]+)");
    private static final Pattern EXC = Pattern.compile(
            "^(?:\\[[^\\]]*\\]: )?(?:Caused by: )?([\\w.$]+(?:Exception|Error))(?::.*)?$");

    public static void log(File logFile, List<PluginInfo> infos, List<Finding> out) {
        if (!logFile.isFile()) {
            return;
        }
        Map<String, String> prefixToPlugin = new LinkedHashMap<>();
        for (PluginInfo i : infos) {
            String pre = JarScanner.pkgRoot(i.main(), 3);
            if (!pre.isEmpty()) {
                prefixToPlugin.put(pre + ".", i.name());
            }
        }

        Map<String, Integer> errCount = new HashMap<>();
        Map<String, Integer> warnCount = new HashMap<>();
        Map<String, String> errSample = new HashMap<>();
        Map<String, Integer> eventErr = new HashMap<>();
        Map<String, Integer> excCount = new LinkedHashMap<>();
        Map<String, Integer> enableErr = new HashMap<>();

        String pendingExc = null;
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(Files.newInputStream(logFile.toPath()), StandardCharsets.ISO_8859_1))) {
            String line;
            while ((line = br.readLine()) != null) {
                Matcher lt = LEVEL_TAG.matcher(line);
                if (lt.matches()) {
                    String plugin = lt.group(2);
                    if (lt.group(1).equals("ERROR")) {
                        errCount.merge(plugin, 1, Integer::sum);
                        errSample.putIfAbsent(plugin, trim(lt.group(3), 140));
                    } else {
                        warnCount.merge(plugin, 1, Integer::sum);
                    }
                }
                Matcher ev = EVENT.matcher(line);
                if (ev.find()) {
                    eventErr.merge(ev.group(2) + "|" + ev.group(1), 1, Integer::sum);
                }
                Matcher en = ENABLE.matcher(line);
                if (en.find()) {
                    enableErr.merge(en.group(1), 1, Integer::sum);
                }

                String t = line.trim();
                if (t.startsWith("at ")) {
                    if (pendingExc != null) {
                        String frame = t.substring(3);
                        for (Map.Entry<String, String> pe : prefixToPlugin.entrySet()) {
                            if (frame.startsWith(pe.getKey())) {
                                excCount.merge(pe.getValue() + "|" + pendingExc, 1, Integer::sum);
                                pendingExc = null;
                                break;
                            }
                        }
                    }
                    continue;
                }
                Matcher ex = EXC.matcher(line);
                if (ex.matches()) {
                    pendingExc = ex.group(1);
                } else if (!t.startsWith("...") && !t.startsWith("Caused by")) {
                    pendingExc = null;
                }
            }
        } catch (Exception e) {
            return;
        }

        for (Map.Entry<String, Integer> e : enableErr.entrySet()) {
            out.add(new Finding(e.getKey(), Severity.KRITIK, "Açılış hatası: eklenti etkinleştirilemedi (" + e.getValue() + " kez)",
                    "Log'da 'Error occurred while enabling' kaydı var; eklenti çalışmıyor.",
                    "Log'da bu satırın hemen altındaki 'Caused by' satırına bak: genelde eksik bağımlılık, bozuk config ya da yanlış Java/MC sürümü. Eklentiyi 26.2 uyumlu sürümüyle değiştir ve config.yml'i silip yeniden oluştur."));
        }
        for (Map.Entry<String, Integer> e : excCount.entrySet()) {
            String[] kv = e.getKey().split("\\|", 2);
            String simple = kv[1].substring(kv[1].lastIndexOf('.') + 1);
            out.add(new Finding(kv[0], excSeverity(simple), "Log'da hata: " + simple + " (" + e.getValue() + " kez)",
                    "latest.log içinde bu eklentinin kodundan kaynaklanan " + kv[1] + " hatası görüldü.",
                    fixFor(simple)));
        }
        for (Map.Entry<String, Integer> e : eventErr.entrySet()) {
            String[] kv = e.getKey().split("\\|", 2);
            out.add(new Finding(kv[0], Severity.ORTA, "Event hatası: " + kv[1] + " (" + e.getValue() + " kez)",
                    "Eklenti bu olayı işlerken hata verdi; olay iptal olabilir, diğer eklentiler etkilenebilir.",
                    "Hata satırının altındaki 'Caused by' kısmına bak; çoğunlukla null kontrolü eksiktir. Eklentiyi güncelle, kendi eklentinse ilgili @EventHandler içine null/izin kontrolü ekle."));
        }
        for (Map.Entry<String, Integer> e : errCount.entrySet()) {
            if (e.getValue() >= 3) {
                out.add(new Finding(e.getKey(), Severity.ORTA, "Log'da " + e.getValue() + " ERROR satırı",
                        "Örnek: " + errSample.get(e.getKey()),
                        "Log'daki mesajı eklentinin sayfasında/Discord'unda ara; config'i kontrol et, eklentiyi güncelle."));
            }
        }
        for (Map.Entry<String, Integer> e : warnCount.entrySet()) {
            if (e.getValue() >= 10) {
                out.add(new Finding(e.getKey(), Severity.DUSUK, "Log'da " + e.getValue() + " WARN satırı",
                        "Eklenti sık sık uyarı üretiyor; genelde config ya da sürüm uyumsuzluğu işaretidir.",
                        "Uyarı metnini oku, config'teki eski ayarları temizle, eklentiyi güncelle."));
            }
        }
    }

    private static String trim(String s, int n) {
        return s.length() <= n ? s : s.substring(0, n) + "...";
    }

    private static Severity excSeverity(String simple) {
        return switch (simple) {
            case "NoClassDefFoundError", "NoSuchMethodError", "AbstractMethodError", "UnsupportedClassVersionError",
                 "ClassNotFoundException", "StackOverflowError", "OutOfMemoryError" -> Severity.YUKSEK;
            default -> Severity.ORTA;
        };
    }

    private static String fixFor(String simple) {
        return switch (simple) {
            case "NullPointerException" ->
                    "Boş (null) değer kullanılıyor. Eklentiyi güncelle; kendi eklentinse getPlayer/getWorld/getItemMeta gibi çağrıların sonucunu null kontrolünden geçir.";
            case "ClassCastException" ->
                    "Yanlış tür dönüşümü. Config'teki değer tipini kontrol et (sayı yerine yazı vb.); kendi kodunda instanceof ile kontrol et.";
            case "IndexOutOfBoundsException", "ArrayIndexOutOfBoundsException" ->
                    "Liste/dizi sınırı aşılıyor. Erişmeden önce size/length kontrolü ekle, komut argümanlarında args.length kontrol et.";
            case "ConcurrentModificationException" ->
                    "Liste dönülürken değiştiriliyor. Listenin kopyası üzerinde dön (new ArrayList<>(liste)) ya da değişiklikleri döngüden sonra yap.";
            case "IllegalStateException" ->
                    "Çoğunlukla ana thread dışında Bukkit API çağrısı. API çağrılarını Bukkit.getScheduler().runTask(...) ile ana thread'e taşı.";
            case "NoClassDefFoundError", "ClassNotFoundException" ->
                    "Gereken sınıf/eklenti yok. Eksik bağımlılığı yükle ya da eklentiyi 26.2 uyumlu sürümüyle değiştir.";
            case "NoSuchMethodError", "AbstractMethodError" ->
                    "Eklenti başka bir sunucu sürümü için derlenmiş. Güncel sürümünü indir; kendi eklentinse paper-api 26.2 ile yeniden derle.";
            case "UnsupportedClassVersionError" ->
                    "Eklenti sunucunun Java sürümünden yeni bir Java ile derlenmiş. Eklentiyi Java 25 hedefiyle derle ya da uyumlu sürümü kullan.";
            case "StackOverflowError" ->
                    "Sonsuz özyineleme var. Kendi eklentinse kendini çağıran metodu/olayı bul (ör. event içinde aynı eventi tetikleme).";
            case "OutOfMemoryError" ->
                    "Bellek yetmiyor ya da sızıntı var. exaroton'da RAM'i artır, eklentiyi güncelle, şüpheli eklentiyi tek tek kapatıp dene.";
            case "NumberFormatException" ->
                    "Sayı beklenen yere yazı girilmiş. Config'teki sayı alanlarını kontrol et; kendi kodunda parse etmeden önce doğrula.";
            default ->
                    "Log'daki tam hata satırını (Caused by) incele; eklentiyi güncelle, config'i kontrol et, sorun sürerse eklentinin geliştiricisine log ile bildir.";
        };
    }
}
